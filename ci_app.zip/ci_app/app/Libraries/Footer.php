<?php
namespace App\Libraries;

class Footer{
    public function load(): string
    {
        return view('base/footer');
    }
}
?>