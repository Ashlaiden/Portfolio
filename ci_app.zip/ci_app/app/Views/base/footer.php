<footer class="text-center mt-auto fs-6 text-secondary">
    <hr class="m-0">
    <div class="my-auto">
        <span class="fw-bold fs-5">©</span> 2025 by <code class="text-secondary fw-bold fs-5">RAMTIN GANJI POUR</code>.
    </div>
</footer>