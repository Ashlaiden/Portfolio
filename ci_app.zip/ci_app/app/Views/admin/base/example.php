<?= $this->extend('admin/base/base') ?>

<?= $this->section('meta_title') ?>

<?= $this->endSection() ?>

<?= $this->section('head') ?>

<?= $this->endSection() ?>

<?= $this->section('style') ?>

<?= $this->endSection() ?>


<?= $this->section('content') ?>

<!-- Content Start -->

<!-- Content End -->

<?= $this->endSection() ?>